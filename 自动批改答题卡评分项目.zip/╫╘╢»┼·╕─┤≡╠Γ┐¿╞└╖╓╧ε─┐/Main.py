import cv2
import numpy as np
import utlis


########################################################################
webCamFeed = True
pathImage = "1.jpg"
cap = cv2.VideoCapture(0)
cap.set(10,160)
heightImg = 500
widthImg  = 500
questions=5
choices=5
ans= [1,2,0,2,4]
########################################################################


count=0

while True:
    img = cv2.imread(pathImage)
    img = cv2.resize(img, (widthImg, heightImg)) # 将图片缩放到合适的大小
    imgFinal = img.copy()
    imageArray =[]
    imgContours = img.copy()  # 为了展示图像边缘设置的变量
    imgBigContour = img.copy()  # 为了展示图像边缘设置的变量
    imgBlank = np.zeros((heightImg,widthImg, 3), np.uint8) # 设置一个空图片以使图片数组的其他图片得以展示出来
    imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) # 将图片变成灰色
    imgBlur = cv2.GaussianBlur(imgGray, (5, 5), 1) #将图片用高斯滤波过滤
    imgCanny = cv2.Canny(imgBlur,10,70) # 用canny检测算子检测边缘

    try:
        ## 找到所有的边缘
        _,contours, hierarchy = cv2.findContours(imgCanny, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE) # 找到所有边缘，RETR_EXTERNAL：外部边缘；CHAIN_APPROX_NONE：没有链近似
        imgContours = cv2.drawContours(imgContours, contours, -1, (0, 255, 0), 10) # 将所有检测到的边缘画出来，用绿色显示
        rectCon = utlis.rectContour(contours) # 把各种边缘过滤，得到符合矩形形状的边缘
        biggestPoints= utlis.getCornerPoints(rectCon[0]) # 找到最大的矩形，也就是有选择框的矩形
        gradePoints = utlis.getCornerPoints(rectCon[1]) # 找到第二大的矩形，也就是评分栏矩形



        if biggestPoints.size != 0 and gradePoints.size != 0:
            #对检测出的矩形进行透视变换
            # 将最大矩形变形
            biggestPoints=utlis.reorder(biggestPoints) # 将有最大面积的边缘的边界点重排序
            imgBigContour=cv2.drawContours(imgBigContour, biggestPoints, -1, (0, 255, 0), 20) # 将最大边缘显示出来
            pts1 = np.float32(biggestPoints) # 将点的类型修改以适于变形
            pts2 = np.float32([[0, 0],[widthImg, 0], [0, heightImg],[widthImg, heightImg]]) # 将点的类型修改以适于变形
            matrix = cv2.getPerspectiveTransform(pts1, pts2) # 给出变换矩阵
            imgWarpColored = cv2.warpPerspective(img, matrix, (widthImg, heightImg)) # 将图片进行透视变换

            # 将第二大矩形变形
            cv2.drawContours(imgBigContour, gradePoints, -1, (255, 0, 0), 20) # DRAW THE BIGGEST CONTOUR
            gradePoints = utlis.reorder(gradePoints) # 边界点重排序
            ptsG1 = np.float32(gradePoints)  # 将点的类型修改以适于变形
            ptsG2 = np.float32([[0, 0], [325, 0], [0, 150], [325, 150]])  # 将点的类型修改以适于变形
            matrixG = cv2.getPerspectiveTransform(ptsG1, ptsG2)# 给出变换矩阵
            imgGradeDisplay = cv2.warpPerspective(img, matrixG, (325, 150)) # 将图片进行透视变换

            # 采用阈值
            imgWarpGray = cv2.cvtColor(imgWarpColored,cv2.COLOR_BGR2GRAY) # 转换成灰度图像
            imgThresh = cv2.threshold(imgWarpGray, 170, 255,cv2.THRESH_BINARY_INV )[1] # 得到二值化后的图像后颜色取反

            boxes = utlis.splitBoxes(imgThresh) # 得到分割成25块的各个选项的图片
            cv2.imshow("Split Test ", boxes[3])
            countR=0#这两个参数用来读取行和列
            countC=0
            myPixelVal = np.zeros((questions,choices)) # 用于保存某一题的所选答案
            for image in boxes:
                #cv2.imshow(str(countR)+str(countC),image)
                totalPixels = cv2.countNonZero(image)#得到所有给定图像上非零点像素的个数
                myPixelVal[countR][countC]= totalPixels
                countC += 1
                if (countC==choices):countR +=1;countC=0

            # 找到用户的答案并显示
            myIndex=[]
            for x in range (0,questions):
                arr = myPixelVal[x]
                myIndexVal = np.where(arr == np.amax(arr)) #找到每一行即每道题的正确答案，也就是将非零像素点最多的那个值找到
                myIndex.append(myIndexVal[0][0])
            #print("USER ANSWERS",myIndex)

            # 得到成绩
            grading=[]
            for x in range(0,questions):
                if ans[x] == myIndex[x]:#将自己的答案和标准答案比较，将每道题的评分放入grading数组里
                    grading.append(1)
                else:grading.append(0)
            #print("GRADING",grading)
            score = (sum(grading)/questions)*100 # 计算出成绩
            #print("SCORE",score)

            # 显示答案，并将其反向透视回未变换前的图片上
            imgResult = imgWarpColored.copy()
            utlis.showAnswers(imgResult,myIndex,grading,ans) # 将答案显示出来
            #utlis.drawGrid(imgWarpColored) # DRAW GRID
            imgRawDrawings = np.zeros_like(imgWarpColored) # 与上色后的答题卡一样大的空白页面
            utlis.showAnswers(imgRawDrawings, myIndex, grading, ans) # 将答案显示在上面
            invMatrix = cv2.getPerspectiveTransform(pts2, pts1) # 反向变换矩阵
            imgInvWarp = cv2.warpPerspective(imgRawDrawings, invMatrix, (widthImg, heightImg)) # 反向透视回未变换前的图片角度

            # 显示成绩，并将其反向透视回未变换前的图片上
            imgRawGrade = np.zeros_like(imgGradeDisplay,np.uint8) # 与得分纸一样大的空白页面
            cv2.putText(imgRawGrade,str(int(score))+"%",(60,100)
                        ,cv2.FONT_HERSHEY_COMPLEX,3,(0,255,255),3) # 将分数显示在图片上
            invMatrixG = cv2.getPerspectiveTransform(ptsG2, ptsG1) # 反向变换矩阵
            imgInvGradeDisplay = cv2.warpPerspective(imgRawGrade, invMatrixG, (widthImg, heightImg)) # 反向透视回未变换前的图片角度

            # 将答案和得分显示在最后的图片上
            imgFinal = cv2.addWeighted(imgFinal, 1, imgInvWarp, 1,0)
            imgFinal = cv2.addWeighted(imgFinal, 1, imgInvGradeDisplay, 1,0)

            # 显示所有变换图片
            imageArray = ([img,imgGray,imgCanny,imgContours],
                          [imgBigContour,imgThresh,imgWarpColored,imgFinal])
            cv2.imshow("Final Result", imgFinal)

    except:
            imageArray = ([img, imgGray, imgCanny, imgContours],
                          [imgBlank, imgBlank, imgBlank, imgBlank])
    # 展示标签
    lables = [["Original","Gray","Edges","Contours"],
              ["Biggest Contour","Threshold","Warpped","Final"]]

    stackedImage = utlis.stackImages(imageArray,0.5,lables)
    cv2.imshow("Result",stackedImage)

    # 当S键按下时保存图片
    if cv2.waitKey(1) & 0xFF == ord('s'):
        cv2.imwrite("Scanned/myImage"+str(count)+".jpg",imgFinal)
        cv2.rectangle(stackedImage, ((int(stackedImage.shape[1] / 2) - 230), int(stackedImage.shape[0] / 2) + 50),
                      (1100, 350), (0, 255, 0), cv2.FILLED)
        cv2.putText(stackedImage, "Scan Saved", (int(stackedImage.shape[1] / 2) - 200, int(stackedImage.shape[0] / 2)),
                    cv2.FONT_HERSHEY_DUPLEX, 3, (0, 0, 255), 5, cv2.LINE_AA)
        cv2.imshow('Result', stackedImage)
        cv2.waitKey(300)
        count += 1